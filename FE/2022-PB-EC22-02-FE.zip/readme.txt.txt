Bởi vì web được viết theo Server-side rendering (SSR) không có code framework FE

Nên nhóm nộp các file Html/css/js
