package com.ec.recauctionec.paypal;

public enum PaypalPaymentIntent {
    sale, authorize, order
}
