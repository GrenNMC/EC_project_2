package com.ec.recauctionec.repositories;

import com.ec.recauctionec.entity.ProductImg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductImgRepo extends JpaRepository<ProductImg,Integer> {

}
