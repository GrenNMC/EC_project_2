package com.ec.recauctionec.location;

public enum Location {
    QUAN_1,
    QUAN_2,
    QUAN_3,
    QUAN_4,
    QUAN_5,
    QUAN_6,
    QUAN_7,
    QUAN_8,
    TP_THU_DUC,
    QUAN_10,
    QUAN_11,
    QUAN_12,
    QUAN_BINHTAN,
    QUAN_BINHTHANH,
    QUAN_GOVAP,
    QUAN_PHUNHUAN,
    QUAN_TANBINH,
    QUAN_TANPHU,
    HUYEN_BINHCHANH,
    HUYEN_CANGIO,
    HUYEN_CUCHI,
    HUYEN_HOCMON,
    HUYEN_NHABE,
    DIFF
}
