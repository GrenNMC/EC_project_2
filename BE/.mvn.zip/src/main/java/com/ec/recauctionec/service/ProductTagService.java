package com.ec.recauctionec.service;

import com.ec.recauctionec.entity.ProductTag;

import java.util.List;

public interface ProductTagService {
    List<ProductTag> findAll();
}
