package com.ec.recauctionec.configs;

public class AppLogging {
    /*public static  Logger  log = LoggerFactory.getLogger(LoggingController.class);*/
}
