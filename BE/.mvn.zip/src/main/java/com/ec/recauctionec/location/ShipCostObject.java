package com.ec.recauctionec.location;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class ShipCostObject {
    private String message;
    private int cost;
}
