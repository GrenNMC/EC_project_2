package com.ec.recauctionec.paypal;

public enum PaypalPaymentMethod {
    credit_card, paypal
}