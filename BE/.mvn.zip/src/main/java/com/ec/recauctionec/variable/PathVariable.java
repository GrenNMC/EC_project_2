package com.ec.recauctionec.variable;

public class PathVariable {
    public static final String CONTEXT_PATH = "http://localhost:8080";
}
