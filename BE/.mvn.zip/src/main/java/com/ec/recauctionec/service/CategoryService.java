package com.ec.recauctionec.service;

import com.ec.recauctionec.entity.Category;

import java.util.List;

public interface CategoryService {
    List<Category> findAll();
}
